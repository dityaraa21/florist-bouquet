<script src="<?php echo base_url() ?>login/js/jquery.min.js"></script>
<script src="<?php echo base_url() ?>login/js/popper.js"></script>
<script src="<?php echo base_url() ?>login/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>login/js/main.js"></script>

</body>

</html>